# GROK — READ THIS FIRST

You are taking over Studigo v2 Phase 4 planning/implementation context from an extensive ChatGPT conversation. Act as senior TypeScript/web/iOS architect, animation engineer, child-centered UX specialist, and release reviewer. Keep continuity with the attached files and linked GitHub source of truth.

## Mission

Implement a **living, responsive orange-dragon Studigo** using engineering techniques extracted from `WGLewis0721/coucou` with `WGLewis0721/rea`, without copying Mochi's protected visuals. Ship **two mutually exclusive Study Room presentations** approved by the product owner:

1. **Floating repositionable dock** — the full small framed window and dragon move as one, persist user-safe position, avoid active controls, remain animated inside.
2. **Fixed companion strip** — waist-up dragon fixed within the strip directly **below the Study Room navigation and above the colored horizontal divider (rail)**, subtle expressive life without changing the existing Phase 3 strip behavior or moving the divider.

They are the same mascot, sharing one motion controller and event semantics; there is no duplicate active character. The existing orange/cream dragon, ivory pointed frills, brown eyes, teal embroidered scholar vest, crayon-shaped tail with flame are canonical. **NO WINGS**; gestures use forearms and paws.

The owner inspected and explicitly approved the two rendered concepts: **“yep I like it. thats exactly it”**. That is approval of motion and placement *concept*, not production code, a specific implementation library or unrelated redesign. The previous character-only video was also approved: **“looks good.”**

## Binding implementation references

- Full source-backed Phase 4 plan: https://github.com/WGLewis0721/Studigo-ai/blob/research/phase4-coucou-rea-behavior-spec/implementation/PHASE4_LIVING_COMPANION_PLAN.md
- Source analysis: https://github.com/WGLewis0721/Studigo-ai/blob/research/phase4-coucou-rea-behavior-spec/design/phase4/COUCOU_REA_BEHAVIOR_EXTRACTION.md
- Planning PR #164: https://github.com/WGLewis0721/Studigo-ai/pull/164 (draft; **not merged** in latest check).
- GitHub sources: https://github.com/WGLewis0721/Studigo-ai , https://github.com/WGLewis0721/coucou , https://github.com/WGLewis0721/rea .
- Three approved preview MP4 URLs are cataloged in `05_ASSET_AND_VIDEO_MANIFEST.md`.
- Raw REA machine evidence is nested in `rea_evidence/rea-evidence-original.zip` (34+ MB JSON unpacked).

## Latest verified status (2026-10-25)

- `main`: `056066fb2b13a0fe8a529bee74c630ea7c43e723` at time of check.
- Phase 3 completion **PR #197 MERGED**; Materials export labels **PR #200 MERGED**.
- Phase 3 four-width evidence PR #196 **OPEN DRAFT** (not a complete acceptance claim).
- Phase 4 PR #164 **OPEN DRAFT**, head `7831ec111d1be34b42e01453fa05a2c28c26cc9a`.
- The Phase 4 branch was created earlier and can lag substantially behind current `main`; **refresh/rebase** before code integration, compare baseline, examine existing changes and current release gates.
- No Phase 4 animation implementation, QA, merged code or production deployment was demonstrated during this chat.

## First actions for Grok if authorized to implement

1. Verify **current** main, PR status, deployed SHA, `AGENTS.md` and root `ENGINEERING.md` before edits. Review the phase3 visual code, source plan and approved videos.
2. Capture **post-Phase-3 baseline** + rollback; do not mistake Oct 15 pre-redesign golden image for today's code.
3. Extract/check a **layered original Studigo rig** from existing canonical sprites; request Higgsfield generation *only* for missing canonical layers. Evaluate CSS/SVG vs Canvas/rig library on real iPhone.
4. Build deterministic, renderer-neutral **motion director** (13 scalar channels + expression), frame-time-normalized motion with priorities, injected clock/RNG, visibility/reduced motion.
5. Integrate behind an **independent Phase 4 feature flag**, retaining old WebP sprites, CompanionContext and existing drag/minimize/resize/touch/prefs behavior. Implement floating and fixed-strip hosts without rewriting learning UI.
6. Hook reactions **only to verified committed learning events**, not inferred correctness. No scoring, mastery, coin/bond progression or DB writes in the presentation layer.
7. Execute four-/five-width tests, keyboard/screen reader, signed-in source/learning flows, real iPhone Safari/iPad performance, rollback. Report exact tested commits and results; never state unperformed verification as complete.

## Critical constraints

- Preserve existing Phase 3 header strip 100%→60% tuck and expand/focus behavior on desktop, phone full-size controls, and stationary colored rail. Fit Studigo to approved strip geometry, not vice versa.
- The current old preference model has `seated`, `dock` (four corners), `scale`, `speech`, `tuck`. To achieve user-approved **free repositioning**, plan a safe normalized position migration while retaining legacy prefs; avoid blocking composer, citations, navigation and answer controls.
- The existing companion owns local DOM window lifecycle. Prefer minimal-change internal extension, **not** a new competing pet runtime.
- Reduced motion, low power, pauses hidden, unmount cleanup, input responsiveness, one character at a time, no added student surveillance.
- Project vision: **Learn. Earn. Play.** Studigo should be a lovable friend who accompanies learning and later games. Do not convert Phase 4 into a gamification/XP implementation.

## Artifact provenance warning

This ZIP gives you a faithful, organized **reconstruction** and exact supporting URLs. It is not a native raw ChatGPT transcript export. Never infer omitted replies or a current GitHub state beyond the dated snapshot. Fetch current canonical repo files before implementing.
