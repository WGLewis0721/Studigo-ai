# Chronological conversation record — Phase 4 Coucou, REA, Higgsfield

This is a message-level **reconstruction** preserving exact meaningful user quotations, decisions and high-fidelity summaries of assistant actions. It omits tool-call mechanics, generic narration and massive intermediate outputs; it is NOT a platform-exported verbatim chat transcript.

## Context before the research

Studigo is an AI study companion, with the motto **Learn. Earn. Play.** Learn is source-grounded studying from learners' uploaded materials; Earn is real achievement progressing reward/customization/companion growth; Play is fun-first companion games (Moon Keep, Core Clash). The approved original companion is a small expressive orange dragon with brown eyes, pale cream belly, ivory frills, a teal/gold scholar vest and a crayon-like orange flame-tail. Existing app includes an independently positionable small window, a header seat, and a full-body Home stage. The code uses sprites and CSS reactions, not yet a rigged procedural animation system. Project demands safe, age-appropriate AI design, strong learning/progression authority boundaries, and iOS/iPadOS parity.

### Exchange 1 — Coucou study initiated

**User (exact substantive request from earlier turn, recalled within this chat):**
> “go look at this github repo https://github.com/WGLewis0721/coucou It has valuable insight for how to better animate Studigo”

**Assistant research/findings:** inspected forked Coucou source and current Studigo code. Coucou Mochi is implemented with procedural scalar pose channels, per-property tweens, frame normalized easing, randomized blinks/glances, autonomous behavior, motion springs, layered drawing, and UI state/mode awareness. Studigo already has gaze/tap/pet/dock/resize/event API, but switches among WebP frames using a ~320 ms behavior loop and CSS effects. The opportunity is richer **coordinated motion**, not blindly reproducing existing features.

**Major technical references:** `windows/src/mochi/engine.ts`, `windows/src/core/anim.ts`, `windows/src/mochi/greeting.ts`, `windows/src/island/fsm.ts`, and corresponding Swift and Android native components. Coucou MIT code is separable from separately protected Mochi art/design/sounds/assets. Avoid reproducing protected creative assets. No implementation changes made at this point.

### Exchange 2 — Explicit Phase 4 and REA scope

**User (exact):**
> “Yes a technical reference. This will be Studigo v2 Phase 4
>
> I forked that repo and this one https://github.com/WGLewis0721/rea Can you use https://github.com/WGLewis0721/rea on https://github.com/WGLewis0721/coucou to get down to the core properites needed to give Studigo similar behavior?”

**Assistant:** analyzed REA's repo/tooling, created isolated branch on Coucou `research/studigo-v2-p4-rea-coucou`, committed a GitHub Actions REA analysis workflow and executed it successfully. **Workflow:** https://github.com/WGLewis0721/coucou/actions/runs/38763880044 . Uploaded complete REA machine analysis; exact original archive is in this ZIP's `rea_evidence/` directory. A source-backed analysis document was added to a new draft Studigo PR #164 (later expanded to comprehensive execution plan).

**Reported analysis scope:** package manifest + 9 selected TS source modules, 9 parsed JS/TS files, 119 relevant inventoried files, 109 excluded intentionally, 35,160 AST nodes, 20,477 semantic nodes, 16,403 semantic relations, 330 function fingerprints, zero parsing errors, 7,696 unknown semantics, **partial graph coverage**. Static analysis not proof of runtime fidelity.

**Derived architecture:** behavioral signals/states → animation scheduler → continuous motion channels → spring/secondary follow-through → original Studigo renderer. Proposed **13 scalar channels**: gazeX/Y, headYaw/Pitch/Roll, eyeOpen, bodyScaleX/Y, rootX/Y, pawGesture (later corrected from abstract wingGesture), softLagX/Y; categorical expressions neutral/curious/focused/joyful/supportive/sleepy. The actual character should have paw/arm movement, **no new wings**. Motion engine receives existing committed assessment signals and visibility/user events; does not mutate grades/mastery.

**Assistant:** Created draft Studigo PR #164 containing `design/phase4/COUCOU_REA_BEHAVIOR_EXTRACTION.md`, later aligned vocabulary to `pawGesture`. Nothing merged or implemented at this stage.

### Exchange 3 — Should more assets be generated?

**User (exact):**
> “do we need to generate more studigo assets in [$higgsfield] ? Coucou has an asset for each of the character's emotes.”

**Assistant:** Checked existing art and Higgsfield connection. Repo already contains numerous approved waist-up and full-body WebP poses and six canonical character reference sheets. Coucou's core engine renders many eye/body/emote variations procedurally; it does not need a separate fully painted standalone bitmap for every mood. Recommended **layered articulated character parts**, pivot references and independently movable eyes, lids, brows, mouth, head, arms/paws, frills, tail, vest, with selective Higgsfield generation only if existing canonical layers are missing. Higgsfield showed Spread projects but no visible Studigo reference elements at that moment (do not infer that past generations were deleted). The mascot must match approved original character identity and no wings.

### Exchange 4 — Market observation

**User (exact):**
> “also I was on the money with making studigo. The FAANG companies are rolling out little pokemon characters of their own (muse, grokbot, dots etc)”

**Assistant:** treated that as broader market validation for expressive/personal-agent characters, with important distinction between superficial chatbot mascots and Studigo's persistence across **Learn / Earn / Play**. This does NOT verify Studigo market viability or instructional outcomes, and Phase 4 is NOT a new loyalty/earning/progression subsystem. The details of all named competitors are not necessary to implement the animation.

### Exchange 5 — Character-only concept video

**User (exact):**
> “can you make a vidoe showing how studigo would look when this is all said and done?”

**Assistant:** generated a 12-second, 16:9, silent Kling 3.0 Pro animation anchored to production full-body sprite `apps/web/public/mascot/companion/full/center.webp` using Higgsfield. Created **single-shot** microbehavior arc: breathing and blink → gaze follows cursor, head follows after eyes → responds to pet → kind thoughtful attention → soft celebratory hop and paw motion, tail/frill follow-through. Render completed, artifact:
https://d8j0ntlcm91z4.cloudfront.net/user_3IkKBBXHZvEZQt2d8pBaRYd083T/hf_20261015_163130_6647ad5b-1046-436d-85a2-f420df05c498.mp4

**User:**
> “looks good.”

That validates the standalone moving character concept, **not** that Phase 4 code exists.

### Exchange 6 — Two UI residences requested

**User (exact meaning):**
> “Now Studigo lives in 2 places in the UI: a dock the user can reposition, and a static doc in the strip between the nav bar and the colored divider. Do a concept video for each of those locatiosn as well.”

**Assistant:** Initially incorrectly said video tools unavailable and returned two detailed production-ready Higgsfield prompts instead. This was a temporary tool-response limitation, not a requirement to use those prompts manually. The user pushed back:

**User (exact):**
> “[$higgsfield] try again”

**Assistant:** used Higgsfield to generate two consistent application screenshot-style UI keyframes, each based on the approved production waist-up Studigo sprite `apps/web/public/mascot/companion/center.webp`. Both concepts use a recreated Study Room UI (not screenshots of actual production). Then generated two 12-second Kling 3.0 Pro videos:

- **Floating dock**: 12 sec, small framed draggable window, blinking/gaze/emotion. Original generative clip did not clearly move the entire dock. Assistant verified frames, then added **deterministic panel relocation** to the final cut so the whole dock moves as one UI element. Approved final:
  https://d2ol7oe51mr4n9.cloudfront.net/user_3IkKBBXHZvEZQt2d8pBaRYd083T/868d115b-2c32-43ec-b409-3bca35fd1c8d.mp4
- **Fixed strip**: 12 sec, orange dragon remains contained on right-hand end of strip **below top nav, above colored divider**, blinks, glances down at learner work, makes small encouraging expressions/paw wave while header remains fixed. Approved final:
  https://d8j0ntlcm91z4.cloudfront.net/user_3IkKBBXHZvEZQt2d8pBaRYd083T/hf_20261015_174105_32b24696-7b5c-4407-bcd0-3f8d622575ce.mp4

**Important:** Videos are *motion/placement design direction*, not literal production UI frames. Preserve actual Phase 3 approved navigation layout and spacing when coding.

### Exchange 7 — Final explicit approval

**User (exact):**
> “yep I like it. thats exactly it”

**Assistant confirmed:** Both video concepts are the approved Phase 4 interaction direction: repositionable expressive dock + fixed embedded strip; one shared motion/behavior system; preserve canonical dragon. User approval is of the concept, not test completion, library choice or merge readiness.

### Exchange 8 — Comprehensive repo plan uploaded

**User (exact):**
> “Upload a comprehensive plan for Studigo v2 phase 4 to the repo”

**Assistant action:** Reviewed repo `AGENTS.md`, `ENGINEERING.md`, Phase 3 UX change ledger, companion files/logic/prefs, mascot references, open PRs and golden rollback docs. Authored **`implementation/PHASE4_LIVING_COMPANION_PLAN.md`**, a detailed 277-line plan (~37k chars) covering approved examples, architecture, UI constraints, asset/rig workflow, deliverables P4-0→P4-7, QA, release/rollback, risk and licensing. Corrected `wingGesture` to `pawGesture` in earlier technical reference. Linked plan from `docs/README.md`, `docs/ROADMAP.md` and `implementation/ENGINEERING_PLAN.md`. Updated existing **draft PR #164**, commit `7831ec111d1be34b42e01453fa05a2c28c26cc9a`. No runtime code modifications or production deploy.

**Assistant response:** Phase 4 plan is in draft and ready for review, while Phase 3 was still open at the time.

### Exchange 9 — This export request

**User (exact):**
> “Compress this chat into a zip file so I can upload to grok so it has fully context”

**Assistant:** assembled this handoff ZIP; checked GitHub again on Oct 25 and discovered **Phase 3 PR #197 and fix PR #200 are now merged**, whereas Phase 4 PR #164 remains draft and PR #196 remains draft. Use the live GitHub state before any coding.

## Governing overall product expectations

The user prioritizes polish, emotional character connection, iPhone/iPad readiness, simple well-executed UX over needless complexity, preserving working code, grounded source-based learning, schoolchild privacy, real tests/release proof, safe incremental PRs and no unnecessary repeated clarifications. Assumptions and recommendations must be separated from user-approved decisions and verified reality.
