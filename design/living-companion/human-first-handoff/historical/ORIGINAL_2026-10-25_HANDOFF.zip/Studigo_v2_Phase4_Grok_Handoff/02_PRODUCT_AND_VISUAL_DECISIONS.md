# Product and visual decisions — authority levels

## A. Explicitly approved by product owner

- This effort is **Studigo v2 Phase 4**. Coucou and REA are **technical references** for animation behavior, NOT templates to copy its character or UI.
- **Character only**: Orange/cream dragon Studigo design maintained; polished breathing, microblinks, gaze tracking, head movement, touch/pet feedback, emotionally appropriate reactions, secondary motion. The initial full-body concept video was explicitly accepted as “looks good.”
- **Exactly two main Study Room UI placements**: (a) repositionable floating dock/window, and (b) stationary dock/character in the horizontal strip **between top nav and colored divider**. Both 12-second concepts were explicitly accepted as “yep I like it. thats exactly it.”
- The floating **dock frame and dragon move together**, the dragon animates within the frame; the fixed-strip companion remains anchored and only body/face parts animate. Two presentations of the **same** Studigo character.
- Comprehensive plan must be in **GitHub repo**; fulfilled via draft PR #164 and comprehensive plan path.

## B. Verified existing product/code constraints — preserve

- The mascot's body reference is authoritative in `docs/brand/mascot/reference/`. Critical features: original brown glossy eyes, ivory pointed frills/horns, orange body with cream chest, teal/gold scholar vest, distinctive crayon-shaped orange flame tail. There are **no wings** in canonical design; use paws/forearms for gestures.
- Existing WebP sprites (waist-up and full-body) and asset source generation pipeline must remain as safe fallback; do not delete existing assets without migration and explicit QA.
- Existing `CompanionContext`, `CompanionHandle` and `CompanionEvent` bridge, browser-local per-room preferences, dock/size/seat/scroll interactions are already implemented. Preserve functionality before enhancing motion.
- Academic state transitions/progression/mastery belong to server-authorized deterministic learning software. Companion may react to real committed events but does **not** grade, advance study state, add points, store student reaction trails or call provider APIs.
- Existing Phase 3 Coach header/strip behavior: desktop expands to 100%, tucks to 60% on interaction/arrival per ledger and expands on hover/focus/click; colored rail does not scale; phone controls stay full size. Do not alter these proportions just to accommodate Phase 4.
- User values **Learn. Earn. Play.**, fun-first game integration later, not interruptions or arbitrary gamified academic incentives in Phase 4.

## C. Architectural choices recommended, not user-locked

- A pure 13-channel TypeScript motion director and categorical expression state.
- Possible layered Canvas 2D/SVG/DOM or lightweight rig runtime; no final renderer chosen until performance + visual fidelity prototype.
- Avatar animation procedural rather than one pre-painted render per emote; layer art only if needed.
- Free-position drag stored as normalized safe-area coordinates, backward compatible with existing four-corner preference.
- Independent `NEXT_PUBLIC_STUDIGO_COMPANION_MOTION` feature flag (initially OFF), retained `NEXT_PUBLIC_STUDIGO_COMPANION` emergency kill switch, room-level canary if appropriate.
- P4-0 through P4-7 work package sequence, subagent organization and acceptance measures.
- Minimal, nonjudgmental encouragement when children struggle, no crying/scolding or “bad learner” expressions.

## D. Not approved / specifically out of scope

- Rebuilding Phase 3 layout, navigation, lesson protocol, grading or source pipeline.
- New wings, dramatic new dragon art, borrowing Mochi's face, colors, branded effects or sounds.
- Native Swift/Kotlin port as required part of this web Phase 4. Future Expo architecture parity can reuse logic but doesn't imply shipping a native app now.
- Dozens of new static emote sprites by default, blanket Higgsfield art regeneration, full 3D rebuild absent proof it's needed.
- Bond/XP/streak economy, learning achievements, gameplay mechanics, voice/video sentiment surveillance.
- Claiming the approved synthetic concept video is a Playwright capture or a finished application feature.
- Merging or deploying the draft Phase 4 code/spec without proper review.

## E. UI behavioral contract in plain language

When no meaningful interaction is happening, Studigo *feels alive* but does not fidget incessantly. When learner types, his eyes track activity with the head following slightly later. When a child submits an answer and the app confirms the result, Studigo gives a restrained, age-appropriate reaction. When touched, Studigo responds warmly. On a correct answer he celebrates; on a missed answer he supports rather than shames; while thinking he appears attentive. Frills and tail move after the core head/torso movement rather than all parts rigidly moving together.

The *floating* version makes a full stable framed window that can be repositioned within safe layout bounds. The *fixed strip* version is smaller/subtler, sits at the actual approved nav-to-divider location, stays there as the learner scrolls, and never pushes the colored divider or cuts off the face. On mobile, a safe compact-seat/strip fallback is allowed if needed for functional screen space, but do not silently redesign approved desktop behavior.
