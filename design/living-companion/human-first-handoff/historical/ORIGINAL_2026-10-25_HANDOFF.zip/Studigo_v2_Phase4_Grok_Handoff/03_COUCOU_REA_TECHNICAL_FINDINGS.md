# Coucou/REA technical findings: motion-system architecture

## Verified research method

Repositories:
- Original source fork: https://github.com/WGLewis0721/coucou
- Tool fork: https://github.com/WGLewis0721/rea
- Successful analysis run: https://github.com/WGLewis0721/coucou/actions/runs/38763880044
- REA output artifact: https://github.com/WGLewis0721/coucou/actions/runs/38763880044/artifacts/11986718097 (retention limited; original is included under `rea_evidence/rea-evidence-original.zip`).
- REA evidence ID: `ev_7b16f8648b412dcbc46be74c9fbe995128bd33c12077b1f01b919c7cfceef845`.
- Analysis branch on Coucou: `research/studigo-v2-p4-rea-coucou`.
- Coucou baseline analyzed: `a95d309a4752c23ae28453819245339800557609` (as recorded in the plan).

The analysis included 10 selected source files (9 code modules + package manifest), 35,160 AST nodes visited, 20,477 semantic nodes, 16,403 semantic relationships, 330 function fingerprints, zero parse failures. Other files were excluded on purpose: **static source analysis, incomplete whole-app coverage; it did not run runtime fidelity/performance tests**. Supplemented by manual source reading.

### Relevant Coucou code

| File | Why it matters |
| --- | --- |
| `windows/src/mochi/engine.ts` | Central BotEngine: scalar pose properties, eye shapes, state config, emote scheduling, look targets, idle, frame-timed `update(dt)`, render layers, physics. |
| `windows/src/core/anim.ts` | Easing, damped Spring, Tracked helpers; spring integration subdivides time and applies damping. |
| `windows/src/core/layout.ts` | Named status/mode/presentation parameters. |
| `windows/src/mochi/greeting.ts` | Authored timeline with anticipation/squash/recovery, reference for first-run entrance only. |
| `windows/src/mochi/outfits.ts` + `wardrobe.ts` | Occlusion/drawing and secondary visual motion; use principles, not Mochi wardrobe artwork. |
| `windows/src/mochi/minibots.ts` | Reusing engine in small presentation contexts. |
| `windows/src/island/fsm.ts` + `island.ts` | UI lifecycle/state machine separate from motion state. |
| macOS `NotchBuddy/Sources/CoucouKit/BotEngine.swift` | Native version of the engine and body/eye/emote logic, including secondary motion. |
| macOS `NotchBuddy/Sources/App/BotCanvasView.swift` | Canvas timeline and pause when hidden. |
| Android `android/app/src/main/kotlin/com/coucou/android/mochi/MochiEngine.kt` | Native Kotlin interpretation; parity reference, not directly portable code. |

The *five cooperating systems*:

1. **Events and states**: agent thinking, waiting, finished, etc.; Studigo adapts to learning activity and trustworthy result events.
2. **Motion scheduling**: property-specific tweens/locks/priorities, finite reactions, easing/settling and ambient schedule.
3. **Continuous pose properties**: per-frame numeric head/eyes/body values, not discrete sprite direction snapshots.
4. **Secondary spring physics**: tail/frill/clothing delayed response, controlled damped overshoot and recovery.
5. **Renderer**: appropriate layered character rig, based on *Studigo*, independent of decision logic.

### Minimal Studigo channel contract (13 numeric scalars + 1 expression)

| Property | Range/units proposal | Role |
| --- | --- | --- |
| gazeX, gazeY | normalized [-1,1] | Follows content/pointer; eyes react before head. |
| headYaw, headPitch, headRoll | rig-local normalized/radians to decide | Continuous head orientation/tilt. |
| eyeOpen | [0,1] | Blink/alertness, not whole-image swap. |
| bodyScaleX, bodyScaleY | near 1 | Breathing, squat, stretch, landing. |
| rootX, rootY | safe local offsets | Body bob, anticipation, hop, settling. |
| pawGesture | [0,1] | Small expressive forearm/paw action (**NOT wingGesture**). |
| softLagX, softLagY | damped local offsets | Frill, tail, vest secondary motion. |
| expression | neutral, curious, focused, joyful, supportive, sleepy | Selects joint/face parameter targets. |

Optional extensions only after baseline: `mouthOpen` (if actually needed), independent tail controls for rich rig, outfit/customization slots, bounded particles. Don't copy Coucou's hard-coded palette, Notch UI, cosmetics, slaps/dizzy, audio or Mochi's branded emote appearances.

### Suggested TypeScript contract

```ts
type MotionExpression =
  | "neutral" | "curious" | "focused" | "joyful" | "supportive" | "sleepy";

type MotionSnapshot = {
  expression: MotionExpression;
  gazeX: number; gazeY: number;
  headYaw: number; headPitch: number; headRoll: number;
  eyeOpen: number;
  bodyScaleX: number; bodyScaleY: number;
  rootX: number; rootY: number;
  pawGesture: number;
  softLagX: number; softLagY: number;
};

type MotionInput =
  | { type: "attention"; x: number; y: number; source: "pointer" | "typing" | "content" }
  | { type: "work"; state: "ready" | "thinking" | "explaining" | "waiting" }
  | { type: "result"; name: "correct" | "wrong" | "blindspot" | "setDone" | "cardGood" | "cardMiss" }
  | { type: "touch"; action: "tap" | "pet" | "dragStart" | "dragEnd" }
  | { type: "lifecycle"; state: "visible" | "hidden" | "suspended" | "reducedMotion" };

interface MotionDirector {
  dispatch(event: MotionInput): void;
  advance(dtMs: number): MotionSnapshot;
  reset(): void;
  dispose(): void;
}
```

**Scheduler priorities:** accessibility/visibility > actual result > direct touch > active learning > gaze > ambient. During drag, UI owns dock position and temporarily suppresses incompatible reactions. Temporary emotes resolve back to stable idle. No cascading dangling timers, no mutable React component state every animation frame, no hidden tab loops, no uncontrolled spring velocity after suspended tabs. Inject monotonic time/seeded randomness for deterministic tests; validate at 30/60/120Hz.

**Render separation:** Motion director is pure, renderer consumes snapshot, UI hosts own layout/control state, existing learning system owns progress/auth; none of the motion code is allowed to grade or write to Supabase. Platform-neutral logic can later be consumed by a native Expo client, if/when that client exists.

## Studigo code that ALREADY exists (inspect fresh on current main)

- `apps/web/components/companion/engine.ts`: existing companion DOM host, drag/dock/pinch, touch/pet, idle/cursor, WebP pose switcher, speech preference and emotion response, 320ms behavior loop. Keep controls/lifecycle ownership and extend animation under flag.
- `apps/web/components/companion/companion.tsx`: `CompanionContext`, `CompanionHandle`, `useCompanionWindow` React bridge. Events and think status already flow in; preserve API compatibility.
- `apps/web/components/companion/companion.css`: CSS effects, window geometry and legacy fallback.
- `apps/web/components/companion/stage.tsx`: Home full-body stage. Don't compromise during Study Room changes.
- `apps/web/components/room/workspace.tsx` and `mode-header.tsx`: Study Room shell and its header/strip colored rail. Keep the existing geometry/interaction lock.
- `apps/web/lib/companion-logic.ts`: `CompanionEvent`, `reactionFor`, `dirPose`, `idleStage`, `chooseDock`, `dockFromDrop` etc. Four-corner docking logic is not equal to unconstrained 2D position.
- `apps/web/lib/companion-prefs.ts`: per-room browser-only prefs; scale shared for device. Backward-compatible safe coordinate migration needed.
- `apps/web/public/mascot/companion/`, `design/companion-demo/assets/`, `docs/brand/mascot/reference/`: existing approved art/rig source and fallback; never destroy or silently replace original mascot.

## Licensing line

Coucou repo MIT-licensed code does **not** mean you can reproduce Mochi's separately copyrighted/trademarked character, visual creative expressions, accessories, media or sounds. Read https://github.com/WGLewis0721/coucou/blob/main/LICENSE-ASSETS.md . Reuse mathematical/state-machine patterns; preserve notices if copying actual MIT text/code; use original Studigo character bible.

## Proven fact vs inference

- **Verified by source/REA:** architecture mechanisms and source relationships in selected TS files; existing Studigo pose-based implementation at time examined.
- **Proposed engineering:** the 13-channel API, runtime choice, scheduling design, layer extraction, new mode selection, new position semantics, native adapter. Not proven implemented.
- **Visual concepts:** generated Higgsfield footage; not runtime tests.
