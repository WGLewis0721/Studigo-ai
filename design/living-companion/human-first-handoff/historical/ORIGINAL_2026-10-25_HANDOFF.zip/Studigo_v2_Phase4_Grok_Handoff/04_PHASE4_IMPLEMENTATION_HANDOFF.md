# Studigo v2 Phase 4 — comprehensive executable implementation handoff

**Canonical long-form plan:**
https://github.com/WGLewis0721/Studigo-ai/blob/research/phase4-coucou-rea-behavior-spec/implementation/PHASE4_LIVING_COMPANION_PLAN.md

This handoff preserves the plan's operational essence; **always read the actual canonical 277-line repo document before coding.** It is the definitive execution plan authored in this chat; the Coucou/REA note is an evidence appendix, not an alternate plan.

## Objective

Deliver the exact **owner-approved** living Studigo behavior within (1) a freely repositionable (safely bounded) floating companion dock, and (2) an animated-but-location-fixed companion in the slim band between nav and colored rail. Both share one motion director and canonical original character art; no duplicate persona, no new study logic, no lost functionality, no unnecessary rewrite.

## Execution work packages

### P4-0 — Fresh baseline, code ownership and rollback

- Fetch latest main and PRs. In the handoff snapshot, Phase 3 PR #197 and Materials fix #200 have **merged**; PR #196 visual evidence remains draft. Current code/CI/production behavior is sole source of truth.
- Read `AGENTS.md`, `ENGINEERING.md`, `docs/PRODUCT.md` as needed, Phase 3 UX ledger, companion files and current documentation.
- Capture a **new post-Phase-3 golden checkpoint**: tree SHA, Vercel deployed revision, 375/390/768/1024/1440 visuals, actual current nav→strip→rail geometry and mobile UI; functional rollback ref. Oct15 pre-redesign rollback is not a substitute.
- Verify signed-in flows, Phase 3 flags (notably room-specific allowlist), keyboard/focus/scroll behavior. Keep new branch entirely isolated until QA.

**Exit:** SHAs and rollback confirmed with referenced evidence; no Phase 3 unreviewed changes accidentally absorbed.

### P4-1 — Character layered-rig feasibility (art director + rendering engineer)

- Inventory current waist-up/full-body sprites, canonical 2D brand sheets, transparent bounds, key facial measurements, head center/pivots, vest/tail/frill occlusion.
- Determine actual missing movable parts: head, pupil/iris/eyelid/brow/mouth, body/chest, left/right paw/forearm, ivory frills, tail/flame, vest layer, shadow. **No wings**.
- Prototype minimal independent gaze→head follow, blink for every orientation, one paw wave, frill+tail spring delay, idle breathing and one supportive/celebratory reaction. Compare CSS/SVG vs Canvas2D vs specialized small rig; reject 3D rewrite absent data.
- Test 116×138 default dock legibility, desktop and real mobile. Generate Higgsfield parts **only** when missing and with strict reference-image identity checks. New videos alone are not an editable rig.

**Exit:** canonical look retained, part/pivot inventory, selected renderer with actual frame-time/bundle evidence and a reversible fallback.

### P4-2 — Deterministic motion core (independent engineer)

- Build pure typed director, normalized scalar channels, expression table, bounded gaze targets, time-delta-normalized tween & damped springs, random blink/idle, event cancellation/preemption/cooldowns, injected RNG/time, hidden/reduced-motion stop, deterministic snapshots.
- Keep grading/AI/storage outside animation. Existing `CompanionEvent` is authoritative; reaction only upon committed event.
- Tests for 30/60/120Hz behavior equivalence, multi-result ordering/priority, repeated events, background/resume, unmount cleanup, no academic-data write paths.

**Exit:** deterministic tested pure logic and independent renderer adapter interface; no UI integration yet.

### P4-3 — Existing companion adapter/renderer integration

- Put chosen rig renderer behind separate Phase 4 motion flag, OFF by default until proven.
- Existing WebP fallback, `NEXT_PUBLIC_STUDIGO_COMPANION=off` kill switch, `CompanionHandle` API and all current touch/drag/resize, speech-off, minimize/restore interactions remain functional. No second engine mounted.
- Observe fallback on missing assets/renderer exceptions; no React re-renders per animation frame or orphaned RAF/listeners.
- Compare same-SHA flag-on and flag-off views.

**Exit:** rendering parity and feature flag fallback demonstrated.

### P4-4 — Floating dock behavior

- The entire small framed window **moves as one**; animation inside is independent. Reposition within safe region by pointer/touch + keyboard alternative; snap/settle naturally without re-parenting learner state.
- Existing preference `dock: br|bl|tr|tl` only covers corner destinations. Add **versioned normalized x/y position** or equivalent to preserve free repositioning; convert existing settings compatibly and don't overwrite persisted user choice with temporary obstacle avoidance.
- Clamp around composer/answer options/citations, nav, modal dialogs, iOS on-screen keyboard, zoom, scrolling and viewport change. Preserve resize, pinch, minimize, release focus.

**Exit:** move to multiple genuinely distinct non-corner positions, reload retains intentional placement, does not obscure critical controls.

### P4-5 — Fixed strip / header seat

- Place actual live component after top nav and before colored rail, right aligned and height-contained. Do not generate an extra horizontal row, shift the rail, or alter approved Coach geometry.
- Preserve **100%-to-60% desktop tuck** and 100% restore on hover/focus/click; test header open, tucked and returning. Phone controls remain full size; a compact fallback is permitted when necessary to preserve reading area.
- In strip, use contained eye/head/paw/frill motion only. Do not displace content or create a second avatar while floating mode active. Provide accessible mode switch back to floating.

**Exit:** identical interaction at approved strip location on actual Phase 3 code, no cropping/duplicate character, clear focus/activation.

### P4-6 — Learning-context emotion choreography

- Wire existing Coach/Learn/Quiz/Cards/Test actions into short, child-friendly responses: idle, follow attention, reading, thinking, correct, supportive missed answer, completion, pet/tap, relocated dock landing.
- `correct` and `setDone` from verified app grading/evidence only; reading a passage or completing ungraded formative step **never** updates mastery or triggers academic reward on its own.
- Use six categorical emotional targets: neutral, curious, focused, joyful, supportive, sleepy. No constant activity or punitive/sad responses to wrong answers.
- Preserve room/topic isolation, new room disposal and cancellation on mode changes.

**Exit:** direct real graded event trigger + coherent expression in both homes; no added API or learning write.

### P4-7 — Integration polish, UAT, accessibility, performance, limited release

- Test width sweep (375×667, 390×844, 768×1024, 1024×768, 1440×900); desktop browsers + real physical iPhone Safari and iPad, pointer coarse/fine, 200% zoom, tab focus, screen reader, reduced motion, background tab, long idle, failing asset fallback.
- Capture actual app videos for both presentations matching approved concept behavior; compare against 12s references without misrepresenting the concept images as UI ground truth.
- Record CPU/frame-time/memory/bundle and input responsiveness before/after. Working target: animation core well under full frame budget; profile low-end hardware rather than invent pass/fail percentages.
- Verify signed-in data, private uploaded sources, current citations, chat sending, nav, quiz choices/grade, flashcard review, no mastery changes. Verify real delivery SHA, readiness, flags, canary, and rollback exercise.

**Exit:** all gates objectively proven; only then authorize PR merge, feature flag enablement and production promotion.

## Task ownership / orchestration

- **Agent A**: reference art, rig, pivots, renderer prototypes, visual identity and optional Higgsfield extraction (no page markup).
- **Agent B**: core deterministic TypeScript director, math and tests (no DOM/layout source).
- **Agent C**: phase3-compatible floating + fixed hosts, position/keyboard/preferences/adapter (starts after agreed contracts and Phase 3 baseline).
- **Integration lead / reviewer**: exact SHA, PR dependency/merges, smoke, device/performance, rollback and explicit product acceptance.

Parallelize A and B only when no conflicting file owners. Integrate serially with small commits and reviewable PRs. Preserve the existing companion logic and tests; do not spawn 3+ agents to rewrite one 600-line file concurrently.

## Flags/rollback design

- Existing `NEXT_PUBLIC_STUDIGO_COMPANION=off`: turns companion off; do not break.
- Proposed `NEXT_PUBLIC_STUDIGO_COMPANION_MOTION=off`: restores old WebP rendering while preserving companion UI if possible.
- Limited room canary may reuse server-owned exact-room allowlist concept; no academic authority.
- In Next.js, client-facing `NEXT_PUBLIC_` flags are commonly **build-time**; don't promise instantaneous changes without deployment and validation. Use post-Phase3 rollout as rollback anchor, not pre-redesign 2026-10-15 tree.

## Privacy and functional invariants

- No camera/microphone/gaze recording, no pointer logging trails, no sentiment profiling. Pointer position is transient, local presentation input.
- Speech/off preferences remain off unless explicitly enabled. No new analytics that leak document text or student behavioral histories.
- Never call LLM or Supabase from animation engine; existing learning evidence is deterministic and scoped.
- No fake UI information, fake academic results, synthetic test completions, or mistaken conclusions from AI concept footage.
- Any failure in motion must never prevent Study Room navigation, input, evidence links, answer choices or grading.

## Exit conditions

1. Identity matches canonical dragon. 2. Gaze smooth, independent blink all directions. 3. At least two spring-lagged parts. 4. Reactions prioritized and return to idle. 5. Whole floating frame moves, persistence works, no blocking critical controls. 6. Fixed strip survives tuck/expand and no duplicates. 7. Real committed learning feedback, no academic changes. 8. Full accessibility/reduced-motion/visibility and clean teardown. 9. Real iPhone Safari, iPad, desktop checks and measured performance. 10. Flag-off and actual production rollback proven; exact shipped SHA and deployment verified.

The canonical Phase 4 plan contains more detail and should win where this handoff abstracts it.
