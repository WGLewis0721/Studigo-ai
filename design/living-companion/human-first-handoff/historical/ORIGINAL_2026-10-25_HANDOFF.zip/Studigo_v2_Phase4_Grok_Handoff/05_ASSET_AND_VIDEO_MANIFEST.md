# Asset, approved video and Higgsfield reference manifest

## Original product assets — visual authority

**Studigo is the orange/cream dragon with large glossy brown eyes, pointed pale ivory frills, orange/cream body and belly, teal gold-embroidered scholar vest, short arms/paws, and crayon-shaped orange tail with glowing flame. He does NOT have wings.** Use his repository assets as the single identity anchor.

| Asset category | Exact repository paths |
| --- | --- |
| Canonical bible | `docs/brand/mascot/README.md` and `docs/brand/mascot/reference/studigo-character-bible.jpg` |
| General design refs | `docs/brand/mascot/reference/studigo-2d-brand-reference.jpg`, `studigo-pose-reference-sheet.jpg`, `studigo-profile-reference.jpg`, `studigo-crayon-tail-reference.jpg`, `studigo-icon-reference.jpg` |
| Full-body video source | `apps/web/public/mascot/companion/full/center.webp` |
| Waist-up dock and strip source | `apps/web/public/mascot/companion/center.webp` |
| Existing shipped waist-up poses | `apps/web/public/mascot/companion/*.webp` (`celebrate`, `support`, `pet`, `poke`, `lean`, `sleep`, `left/right`, `up/down`, diagonals, etc.) |
| Existing full-body poses | `apps/web/public/mascot/companion/full/*.webp` (`wave`, `leap`, `celebrate`, `read` and gaze directions) |
| Original sprite-generation inputs | `design/companion-demo/assets/` with `design/companion-demo/build_public_demo.py` |

The existing image set was approved around October 1, 2026 according to `docs/brand/mascot/README.md`. Don't regenerate his face or body proportions to fix animation. Treat existing sprites as renderer fallback and art guides. In the earlier check, there were **13 full-body and 15 waist-up pose names** including mirrored direction aliases; actual files on disk need a fresh inventory. Shipped WebP totals can differ because left-diagonal poses are mirrored rather than stored as separate files.

## The three OWNER-APPROVED videos

### V1 — Living Studigo, character-only

**Direct video:**
https://d8j0ntlcm91z4.cloudfront.net/user_3IkKBBXHZvEZQt2d8pBaRYd083T/hf_20261015_163130_6647ad5b-1046-436d-85a2-f420df05c498.mp4

- Higgsfield model: Kling 3.0, image-to-video, pro, 12 sec, 16:9, audio off.
- Image anchor: actual original full-body orange dragon production sprite `.../full/center.webp`.
- Action timings: 0–2.5s subtle breathing/blink/tail-flame; 2.5–4.7s glowing cursor attention, eyes track before head; 4.7–6.8s petting, happy eye close, snout lean, frills and tail delayed settle; 6.8–9s thoughtful attention/head tilt; 9–12s quiet success celebration, crouch, hop/paw motion and elastic landing.
- User response: **“looks good.”**
- Still a concept; procedural code has not been implemented.

### V2 — Floating repositionable dock

**FINAL APPROVED video (use this, not the original uncorrected version):**
https://d2ol7oe51mr4n9.cloudfront.net/user_3IkKBBXHZvEZQt2d8pBaRYd083T/868d115b-2c32-43ec-b409-3bca35fd1c8d.mp4

- Recreated responsive study UI screenshot generated with Higgsfield GPT Image 2.5 using production waist-up Studigo sprite as visual input; video generated Kling 3.0 Pro, 12 sec, 16:9, silent.
- UI: top navigation, colored rail/divider, study content, a distinct small rounded framed **floating dock** on right. Original presentation approximate 116×138 CSS px base in actual code, not the screenshot's synthetic proportions. Actual Study Room UI must prevail.
- Action: breathing/blinking/gaze while dock is docked lower right; pointer grabs frame; **the entire window translates diagonally to a visibly new right-side position**; movement eases and stops; dragon subtly responds to relocation and reacts to a learner event.
- Raw Higgsfield initial animation job **32a4c8db-e86b-4a06-85ec-a5dca392125b** did not clearly move the dock. A **separate deterministic video editing pass** added unambiguous rigid-frame relocation. Final media asset **868d115b-2c32-43ec-b409-3bca35fd1c8d** is what user approved.
- Requires actual app implementation for dragging, safe-zone clamping and persistence. Video does NOT validate existing code.

### V3 — Fixed companion header strip

**Direct video:**
https://d8j0ntlcm91z4.cloudfront.net/user_3IkKBBXHZvEZQt2d8pBaRYd083T/hf_20261015_174105_32b24696-7b5c-4407-bcd0-3f8d622575ce.mp4

- Recreated Study Room UI background with original waist-up mascot; Kling 3.0 Pro, 12 sec, 16:9, silent.
- CRITICAL layout: TOP NAV → NARROW HORIZONTAL STRIP with waist-up Studigo at right → COLOR DIVIDER/RAIL → scrolling study content. No independent floating window.
- Studigo keeps his body rooted in strip, subtle breathing and eye tracking toward questions, friendly attentive head tilt, small contained paw expression/mini celebration. Main learning content changes or scrolls while character, strip/nav and colored divider retain their exact place.
- User approved it together with V2: **“yep I like it. thats exactly it.”**

### All three are DESIGN references

They demonstrate approved mood/motion and broad placement. Generated visual UI may have imaginary texts or altered layout; do not use it as a product screenshot or substitute for actual component/route analysis. They are not proof of frame-rate, production grade correctness, battery cost, accessibility, privacy or user testing.

## Higgsfield usage notes

During prior check the connected Higgsfield workspace had only two **Spread** media projects visible and no named Studigo reusable character reference element. That does **not** prove Studigo reference generations were deleted; they may be in different workspace/account contexts or outside the reference-element catalog. The prior image-to-video runs used **GitHub raw production images** as reference media successfully.

The visual asset workflow should be:

1. Start with the exact approved mascot image from repo and brand bible.
2. Inventory and separate only truly needed layers into a 2D rig (head, eyes, pupils, eyelids/brows, mouth, vest/body, paws, frills, segmented tail/flame).
3. Use Higgsfield for clean missing image references, front/three-quarter turnaround, or individual layer art only if technical decomposition fails. Confirm consistent facial features across frames. Video outputs may illustrate motion but are NOT editable separated assets.
4. Add pivots, alpha masks, occlusion order, atlas or layered SVG source, with source provenance and neutral pose side-by-side comparison.
5. Use procedural motion (13 scalars + categorical expression), not thirty finished emote images, to generate living performance. Existing WebPs remain fallback.

## Visual-language dos and don'ts

**Do:** tiny asynchronous blinking, slow eye followed by head, occasional idle glances, nonjudgmental curiosity, joyful correct-answer microhop, frill and tail delayed motion, soft landing, readable UI, crisp controls, iPhone-safe scale, muted ambient effects.

**Don't:** added wings, reinvented vest/face/frills/tail, continuous distracting bouncing, punitive errors, huge confetti, generated fake grades/sources, obscured composer, free-floating mascot in strip mode, distorted bezel, moving the entire page when moving dock, or moving rail/header geometry.

## Licensing

https://github.com/WGLewis0721/coucou/blob/main/LICENSE-ASSETS.md — Coucou's MIT engineering source does not license the Mochi character visuals, audio, or protected creative expression assets. Studigo must be original. Any direct MIT source adaptation must retain proper notices.

## MP4 availability

External Higgsfield/CloudFront links were returned from successfully completed jobs in this conversation. Their continued availability cannot be guaranteed; Grok should retrieve and preserve authorized permanent copies in the project design archive before future release sign-off, while keeping source URL/provenance. This ZIP intentionally **does not embed the three large videos**; they remain directly linked above.
