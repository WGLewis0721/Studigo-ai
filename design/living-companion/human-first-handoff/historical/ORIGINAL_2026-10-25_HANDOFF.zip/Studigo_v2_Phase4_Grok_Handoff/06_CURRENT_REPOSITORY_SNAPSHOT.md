# Verified repository state as of October 25, 2026

This is the **latest tool-verified snapshot during this ChatGPT handoff**, not an enduring claim. GROK MUST RECHECK AGAINST GITHUB BEFORE CHANGES.

## GitHub main and PR snapshot

| Ref | Status verified 2026-10-25 | SHA / notes |
| --- | --- | --- |
| `WGLewis0721/Studigo-ai` `main` | Accessible | `056066fb2b13a0fe8a529bee74c630ea7c43e723` |
| [PR #164](https://github.com/WGLewis0721/Studigo-ai/pull/164) `research/phase4-coucou-rea-behavior-spec` → main | **OPEN DRAFT**, **NOT merged** | Head `7831ec111d1be34b42e01453fa05a2c28c26cc9a`, contains canonical P4 plan and REA analysis |
| [PR #197](https://github.com/WGLewis0721/Studigo-ai/pull/197) Phase 3 completion | **CLOSED / MERGED** | Last head `364b3f11813fcec0ed65599bc8ff8dfa3697372f` |
| [PR #200](https://github.com/WGLewis0721/Studigo-ai/pull/200) Materials export labels | **CLOSED / MERGED** | Last head `09d2d34c1c8a1d6732915a3c265c60b76c6a8aab` |
| [PR #196](https://github.com/WGLewis0721/Studigo-ai/pull/196) four-width Phase 3 visual evidence | **OPEN DRAFT**, not merged | `011e237a59d13ea05df66fb311f50ee6b4772415` |

Earlier in conversation (Oct16) #197 and #200 were still open. That status is **obsolete** and should be treated as historical timeline only. The exact Phase 3 production deployment SHA and physical-device acceptance were **not reverified** in the latest PR-status check; merged PR is not proof of all release gates or production.

## Phase 4 draft-branch content verified during plan upload

- `implementation/PHASE4_LIVING_COMPANION_PLAN.md` — 277-line comprehensive execution document (~37k text chars).
- `design/phase4/COUCOU_REA_BEHAVIOR_EXTRACTION.md` — static analysis/research.
- `docs/README.md` — navigation link to P4 docs.
- `docs/ROADMAP.md` — planned-but-not-implemented Phase 4 reference.
- `implementation/ENGINEERING_PLAN.md` — related specialist plan pointer.

Branch had **documentation-only** additions, no app source modifications in PR #164 on its last inspected diff. Previous comparison as of Oct16 indicated it was behind `main` by around 50 commits; that count is historical and likely changed by Oct25. Rebase/update appropriately before merging, never assume the draft branch is current production source code.

## Engineering rules in repo

- `AGENTS.md`: read root `ENGINEERING.md` first, then specialist docs as relevant, no repo-wide irrelevant scan; preserve RLS, source grounding, security/learning authority; review current owners/test contracts before touching code; feature branches/PRs for material work.
- `ENGINEERING.md`: Next.js 16 + React web/PWA, pnpm; deterministic learning director/retained evidence, Supabase private data; AI provider boundary in `packages/ai`; future Expo/React Native is documented but a full native app was not in monorepo as of prior audit.
- `docs/PRODUCT.md`, `docs/ARCHITECTURE.md`, `docs/DESIGN_SYSTEM.md`, `docs/ROADMAP.md`, `docs/COMPANION_PARITY_PLAN.md` are design and technical authority references. Current implementation wins over stale prose.
- `docs/ux/PHASE3_UI_CHANGE_LEDGER_2026-10-15.md`: historical Phase 3 geometry/risk documentation. Its open/closed release statements need fresh verification since Phase 3 work has merged.
- `docs/golden/2026-10-15/`: **pre-redesign** historical baseline. Phase 4 should take a **new post-Phase-3 baseline**, not roll back post-Phase-3 production to pre-redesign merely to disable animation.

## What was not done in this conversation

No Phase 4 rigging source files generated or committed to Studigo. No 13-channel animation runtime implemented. No feature flag created. No persistence migration. No production UI or API changed by Phase 4 PR #164. No physical iPhone/iPad testing of P4 code. No proof of current deploy/prod SHA. No release approval; synthetic video output is separate from implemented functionality.

## Planning consequences

Phase 3 merge eliminates an earlier blocker to *starting investigation/integration*, but **does not automatically satisfy** animation-specific or device accessibility acceptance. Before Phase 4 coding, find actual latest main owner paths/layout and check production baseline. Land scoped reviewed P4 PRs behind independent flag; do not simultaneously change learning/quiz/Coach business logic.
