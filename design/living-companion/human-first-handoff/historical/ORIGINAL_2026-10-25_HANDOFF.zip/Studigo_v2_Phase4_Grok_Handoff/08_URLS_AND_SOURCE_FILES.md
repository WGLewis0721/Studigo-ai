# Complete link and code-source index

## Primary GitHub entities

- Studigo web repo: https://github.com/WGLewis0721/Studigo-ai
- Current production entry: https://studigo-ai.vercel.app
- Coucou fork: https://github.com/WGLewis0721/coucou
- REA fork: https://github.com/WGLewis0721/rea
- Draft Phase 4 plan PR: https://github.com/WGLewis0721/Studigo-ai/pull/164
- Phase 3 completed PR: https://github.com/WGLewis0721/Studigo-ai/pull/197
- Phase 3 Materials fix PR: https://github.com/WGLewis0721/Studigo-ai/pull/200
- Phase 3 visual evidence PR: https://github.com/WGLewis0721/Studigo-ai/pull/196

## Canonical Phase 4 documents on PR #164 branch

- Comprehensive executable Phase 4 plan:
  https://github.com/WGLewis0721/Studigo-ai/blob/research/phase4-coucou-rea-behavior-spec/implementation/PHASE4_LIVING_COMPANION_PLAN.md
- REA source-backed investigation:
  https://github.com/WGLewis0721/Studigo-ai/blob/research/phase4-coucou-rea-behavior-spec/design/phase4/COUCOU_REA_BEHAVIOR_EXTRACTION.md
- Repo docs routing changes on same branch: `docs/README.md`, `docs/ROADMAP.md`, `implementation/ENGINEERING_PLAN.md`.

## Existing companion code

All paths relative to the root of Studigo repo. Use live main or accepted working branch as ground truth:

- `AGENTS.md`
- `ENGINEERING.md`
- `apps/web/components/companion/engine.ts`
- `apps/web/components/companion/companion.tsx`
- `apps/web/components/companion/companion.css`
- `apps/web/components/companion/stage.tsx`
- `apps/web/components/companion/figure.tsx`
- `apps/web/components/room/workspace.tsx`
- `apps/web/components/room/mode-header.tsx`
- `apps/web/lib/companion-logic.ts`
- `apps/web/lib/companion-prefs.ts`
- `apps/web/lib/companion-logic.test.ts`
- `apps/web/public/mascot/companion/center.webp`
- `apps/web/public/mascot/companion/full/center.webp`
- `design/companion-demo/assets/`
- `design/companion-demo/build_public_demo.py`
- `docs/brand/mascot/README.md` and `/reference/`
- `docs/COMPANION_PARITY_PLAN.md`
- `docs/ux/PHASE3_UI_CHANGE_LEDGER_2026-10-15.md`
- `docs/golden/2026-10-15/README.md`
- `docs/DESIGN_SYSTEM.md`
- `docs/PRODUCT.md`
- `docs/ARCHITECTURE.md`

## Coucou source snippets of significance

- TS engine: https://github.com/WGLewis0721/coucou/blob/main/windows/src/mochi/engine.ts
- TS easing/spring: https://github.com/WGLewis0721/coucou/blob/main/windows/src/core/anim.ts
- TS state layout: https://github.com/WGLewis0721/coucou/blob/main/windows/src/core/layout.ts
- TS greeting choreography: https://github.com/WGLewis0721/coucou/blob/main/windows/src/mochi/greeting.ts
- TS state machine: https://github.com/WGLewis0721/coucou/blob/main/windows/src/island/fsm.ts
- TS UI island: https://github.com/WGLewis0721/coucou/blob/main/windows/src/island/island.ts
- macOS native animation: https://github.com/WGLewis0721/coucou/blob/main/NotchBuddy/Sources/CoucouKit/BotEngine.swift
- macOS Canvas timeline: https://github.com/WGLewis0721/coucou/blob/main/NotchBuddy/Sources/App/BotCanvasView.swift
- Android engine: https://github.com/WGLewis0721/coucou/blob/main/android/app/src/main/kotlin/com/coucou/android/mochi/MochiEngine.kt
- License separation: https://github.com/WGLewis0721/coucou/blob/main/LICENSE-ASSETS.md

## REA successful static research

- Run: https://github.com/WGLewis0721/coucou/actions/runs/38763880044
- Machine evidence GitHub artifact: https://github.com/WGLewis0721/coucou/actions/runs/38763880044/artifacts/11986718097
- Original same evidence included in archive under `rea_evidence/rea-evidence-original.zip` for offline analysis.

## All three approved videos

- Standalone living dragon: https://d8j0ntlcm91z4.cloudfront.net/user_3IkKBBXHZvEZQt2d8pBaRYd083T/hf_20261015_163130_6647ad5b-1046-436d-85a2-f420df05c498.mp4
- **Approved final floating dock:** https://d2ol7oe51mr4n9.cloudfront.net/user_3IkKBBXHZvEZQt2d8pBaRYd083T/868d115b-2c32-43ec-b409-3bca35fd1c8d.mp4
- **Approved final fixed strip:** https://d8j0ntlcm91z4.cloudfront.net/user_3IkKBBXHZvEZQt2d8pBaRYd083T/hf_20261015_174105_32b24696-7b5c-4407-bcd0-3f8d622575ce.mp4

## Direct raw Markdown links — to fetch canonical documents

- https://raw.githubusercontent.com/WGLewis0721/Studigo-ai/research/phase4-coucou-rea-behavior-spec/implementation/PHASE4_LIVING_COMPANION_PLAN.md
- https://raw.githubusercontent.com/WGLewis0721/Studigo-ai/research/phase4-coucou-rea-behavior-spec/design/phase4/COUCOU_REA_BEHAVIOR_EXTRACTION.md

## Source retrieval helper

Run `bash FETCH_CANONICAL_REPO_DOCS.sh` in a GitHub-network-enabled shell. It downloads copies of the **actual canonical repo plans** rather than relying on the reconstructed content; it also creates a simple fetch audit. Do not execute unknown scripts from a ZIP blindly: inspect the helper first. It uses public raw GitHub URLs and `curl`, and writes only inside `fetched_repo_docs/`.
