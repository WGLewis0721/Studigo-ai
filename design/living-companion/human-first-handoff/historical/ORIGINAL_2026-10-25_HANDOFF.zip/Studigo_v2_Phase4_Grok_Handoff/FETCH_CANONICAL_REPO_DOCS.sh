#!/usr/bin/env bash
# Optional convenience helper. Downloads publicly readable, canonical planning sources.
# Read before executing. It does not write to GitHub, to the app or to any live database.
set -euo pipefail
BASE='https://raw.githubusercontent.com/WGLewis0721/Studigo-ai'
BRANCH='research/phase4-coucou-rea-behavior-spec'
mkdir -p fetched_repo_docs
curl --fail --location --silent --show-error "$BASE/$BRANCH/implementation/PHASE4_LIVING_COMPANION_PLAN.md" -o fetched_repo_docs/PHASE4_LIVING_COMPANION_PLAN.md
curl --fail --location --silent --show-error "$BASE/$BRANCH/design/phase4/COUCOU_REA_BEHAVIOR_EXTRACTION.md" -o fetched_repo_docs/COUCOU_REA_BEHAVIOR_EXTRACTION.md
curl --fail --location --silent --show-error "$BASE/main/AGENTS.md" -o fetched_repo_docs/AGENTS.md
curl --fail --location --silent --show-error "$BASE/main/ENGINEERING.md" -o fetched_repo_docs/ENGINEERING.md
sha256sum fetched_repo_docs/*.md > fetched_repo_docs/SHA256SUMS.txt
printf 'Downloaded canonical planning references. Recheck latest main/PR state before coding.\n'
